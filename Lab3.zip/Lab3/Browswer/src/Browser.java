
import java.io.IOException;

import javax.swing.*;

public class Browser {
	
	public static void main(String[] args) {
	JEditorPane browserPane = new JEditorPane();
	browserPane.setEditable(false);
	JButton backButton = new JButton();
	browserPane.setEditable(false);
	JTabbedPane tabbedPane = new JTabbedPane();
	browserPane.setEditable(false);
	JTextField textArea = new JTextField();
	
	
	textArea.setBounds(300,20,400,35);
	textArea.setText("http://graceland.brightspace.com");
	
	
	
	JEditorPane Editorpane1 = new JEditorPane();
	browserPane.setEditable(false);
	JEditorPane Editorpane2 = new JEditorPane();
	browserPane.setEditable(false);
	JFrame browserWindow = new JFrame("<Nick's> Web Browser");

	try {
	  browserPane.setPage(textArea.getText());
	  Editorpane1.setPage("http://google.com");
	  Editorpane2.setPage("http://google.com");
	}catch (IOException e) {
		System.out.println("error loading page");
	} 
	backButton.addActionListener();
	
	tabbedPane.addTab("Tab1", null, browserPane);
	tabbedPane.addTab("Tab2", null, browserPane);
	browserWindow.add(backButton);
	browserWindow.add(textArea);
	browserWindow.add(tabbedPane);
	
	browserWindow.add(browserPane);
	browserWindow.setSize(1200,900);
	browserWindow.setVisible(true);}
	
	browswerWindow.Close();
}
